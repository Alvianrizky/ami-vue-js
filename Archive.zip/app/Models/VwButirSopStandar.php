<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class VwButirSopStandar extends Model
{
    use HasFactory;

    protected $table = 'vw_butir_sop_standar_sop';
}
