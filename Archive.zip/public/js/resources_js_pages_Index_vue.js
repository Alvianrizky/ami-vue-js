"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["resources_js_pages_Index_vue"],{

/***/ "./resources/js/pages/Index.vue":
/*!**************************************!*\
  !*** ./resources/js/pages/Index.vue ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Index_vue_vue_type_template_id_71c33819___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Index.vue?vue&type=template&id=71c33819& */ "./resources/js/pages/Index.vue?vue&type=template&id=71c33819&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

var script = {}


/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__.default)(
  script,
  _Index_vue_vue_type_template_id_71c33819___WEBPACK_IMPORTED_MODULE_0__.render,
  _Index_vue_vue_type_template_id_71c33819___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/Index.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/pages/Index.vue?vue&type=template&id=71c33819&":
/*!*********************************************************************!*\
  !*** ./resources/js/pages/Index.vue?vue&type=template&id=71c33819& ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Index_vue_vue_type_template_id_71c33819___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Index_vue_vue_type_template_id_71c33819___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Index_vue_vue_type_template_id_71c33819___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Index.vue?vue&type=template&id=71c33819& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Index.vue?vue&type=template&id=71c33819&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Index.vue?vue&type=template&id=71c33819&":
/*!************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/Index.vue?vue&type=template&id=71c33819& ***!
  \************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", [
    _c(
      "nav",
      { staticClass: "navbar navbar-expand-lg navbar-light bg-light" },
      [
        _c(
          "div",
          { staticClass: "container-fluid" },
          [
            _c(
              "router-link",
              { staticClass: "navbar-brand", attrs: { to: { name: "Index" } } },
              [
                _c("img", {
                  attrs: { src: "images/logo.png", width: "30", height: "30" }
                }),
                _vm._v(" SIJAMU\n            ")
              ]
            ),
            _vm._v(" "),
            _vm._m(0),
            _vm._v(" "),
            _c(
              "div",
              {
                staticClass: "collapse navbar-collapse",
                attrs: { id: "navbarSupportedContent" }
              },
              [
                _c("ul", { staticClass: "navbar-nav ms-auto" }, [
                  _c(
                    "li",
                    { staticClass: "nav-item mx-2" },
                    [
                      _c(
                        "router-link",
                        {
                          staticClass: "nav-link",
                          attrs: { to: { name: "Index" } }
                        },
                        [
                          _c("span", { staticClass: "fa fa-home" }),
                          _vm._v("\n                            Beranda")
                        ]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _vm._m(1),
                  _vm._v(" "),
                  _vm._m(2),
                  _vm._v(" "),
                  _vm._m(3)
                ])
              ]
            )
          ],
          1
        )
      ]
    ),
    _vm._v(" "),
    _c("section", { attrs: { id: "banner" } }, [
      _c("div", { staticClass: "inner" }, [
        _c("h2", [_vm._v("SISTEM INFORMASI PENJAMINAN MUTU")]),
        _vm._v(" "),
        _vm._m(4),
        _vm._v(" "),
        _c("ul", { staticClass: "actions" }, [
          _c(
            "li",
            [
              _c(
                "router-link",
                {
                  staticClass: "btn btn-primary btn-lg text-white",
                  attrs: { to: { name: "Login" } }
                },
                [
                  _c("span", { staticClass: "fa fa-sign-in-alt" }),
                  _vm._v(" Login\n                    ")
                ]
              )
            ],
            1
          )
        ])
      ])
    ]),
    _vm._v(" "),
    _vm._m(5),
    _vm._v(" "),
    _vm._m(6),
    _vm._v(" "),
    _vm._m(7),
    _vm._v(" "),
    _vm._m(8)
  ])
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "button",
      {
        staticClass: "navbar-toggler",
        attrs: {
          type: "button",
          "data-bs-toggle": "collapse",
          "data-bs-target": "#navbarSupportedContent",
          "aria-controls": "navbarSupportedContent",
          "aria-expanded": "false",
          "aria-label": "Toggle navigation"
        }
      },
      [_c("span", { staticClass: "navbar-toggler-icon" })]
    )
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("li", { staticClass: "nav-item mx-2" }, [
      _c(
        "a",
        {
          staticClass: "nav-link",
          attrs: { "data-bs-toggle": "modal", "data-bs-target": "#ModalProfil" }
        },
        [_c("span", { staticClass: "fa fa-info-circle" }), _vm._v(" Profil")]
      )
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "li",
      {
        staticClass: "nav-item mx-2",
        attrs: {
          "data-bs-toggle": "modal",
          "data-bs-target": "#ModalTentangLpm"
        }
      },
      [
        _c("a", { staticClass: "nav-link" }, [
          _c("span", { staticClass: "fa fa-bookmark" }),
          _vm._v(" Tentang LPM")
        ])
      ]
    )
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "li",
      {
        staticClass: "nav-item mx-2",
        attrs: { "data-bs-toggle": "modal", "data-bs-target": "#ModalKontak" }
      },
      [
        _c("a", { staticClass: "nav-link" }, [
          _c("span", { staticClass: "fa fa-phone-alt" }),
          _vm._v(" Kontak")
        ])
      ]
    )
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("p", { staticClass: "text-white" }, [
      _c("strong", [_vm._v("STMIK EL RAHMA YOGYAKARTA")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "main-footer bg-light" }, [
      _c("div", { staticClass: "float-right d-none d-sm-inline" }, [
        _vm._v("\n            STMIK ElRahma Yogyakarta\n        ")
      ]),
      _vm._v(" "),
      _c("strong", [
        _vm._v("Copyright © 2021 SIJAMU - Sistem Informasi Penjaminan Mutu ")
      ]),
      _vm._v(" All\n        rights reserved.\n    ")
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "div",
      {
        staticClass: "modal fade",
        attrs: { id: "ModalProfil", tabindex: "-1", role: "dialog" }
      },
      [
        _c(
          "div",
          {
            staticClass: "modal-dialog modal-lg text-dark",
            attrs: { role: "document" }
          },
          [
            _c("div", { staticClass: "modal-content" }, [
              _c("div", { staticClass: "modal-header" }, [
                _c("div", { staticClass: "logo-login text-center" }, [
                  _c("em", { staticClass: "glyphicon glyphicon-info-sign" }),
                  _vm._v(" "),
                  _c("h4", { staticClass: "modal-title" }, [
                    _vm._v("PROFIL STMIK ELRAHMA")
                  ])
                ]),
                _vm._v(" "),
                _c("button", {
                  staticClass: "btn-close",
                  attrs: {
                    type: "button",
                    "data-bs-dismiss": "modal",
                    "aria-label": "Close"
                  }
                })
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "modal-body" }, [
                _c("h2", [_vm._v("Tentang STMIK El Rahma Yogyakarta")]),
                _vm._v(" "),
                _c("div", { staticClass: "row" }, [
                  _c("div", { staticClass: "col-md-4" }, [
                    _c("img", {
                      attrs: {
                        src: "images/gedung1.jpg",
                        width: "250",
                        height: "150"
                      }
                    })
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-md-8" }, [
                    _c("p", [
                      _vm._v(
                        "\n                                STMIK EL RAHMA Yogyakarta adalah Perguruan Tinggi Informatika dan Ilmu Komputer di\n                                bawah naungan Yayasan El Rahma Yogyakarta dalam pembinaan Kementerian Pendidikan dan\n                                Kebudayaan Republik Indonesia. STMIK EL RAHMA Yogyakarta berdiri dan menyelenggarakan\n                                operasional kegiatan pendidikan berdasarkan SK Mendiknas No. 155/D/0/2001. STMIK EL\n                                RAHMA Yogyakarta memiliki misi dan positioning JAGO IT, QURANI, LULUS JADI JUTAWAN.\n                                Profil lulusan STMIK EL RAHMA adalah kompeten di bidang informatika dan komputer,\n                                bahasa asing, berjiwa pengusaha dan berkarakter Qur'ani.\n                            "
                      )
                    ])
                  ])
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "row" }, [
                  _c("div", { staticClass: "col-md-8" }, [
                    _c("h3", [_vm._v("Visi")]),
                    _vm._v(" "),
                    _c("p", [
                      _vm._v(
                        "\n                                Visi STMIK El Rahma Yogyakarta adalah “Menjadi Perguruan Tinggi Komputer yang\n                                Unggul, Mandiri dan Qur’ani Tingkat Nasional pada tahun 2025.”\n                            "
                      )
                    ])
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "col-md-4" }, [
                    _c("p", [
                      _c("img", {
                        attrs: {
                          src: "images/dosen.jpg",
                          width: "250",
                          height: "150"
                        }
                      })
                    ])
                  ])
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "row" }, [
                  _c("div", { staticClass: "col-md-12" }, [
                    _c("h3", [_vm._v("Misi")]),
                    _vm._v(" "),
                    _c("p", [
                      _c("ol", [
                        _c("li", [
                          _vm._v(
                            "Menyelenggarakan tridharma perguruan tinggi yang berkualitas sesuai dengan\n                                        standar akreditasi."
                          )
                        ]),
                        _vm._v(" "),
                        _c("li", [
                          _vm._v(
                            "Menyiapkan lulusan yang kompeten, mandiri, berani mengembangkan potensi\n                                        diri, kreatif dan bertanggungjawab."
                          )
                        ]),
                        _vm._v(" "),
                        _c("li", [
                          _vm._v(
                            "Menyelenggarakan pendidikan tinggi yang berlandaskan pada nilai-nilai\n                                        qurani."
                          )
                        ])
                      ])
                    ])
                  ])
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "row" }, [
                  _c("div", { staticClass: "col-md-12" }, [
                    _c("h3", [_vm._v("Tujuan")]),
                    _vm._v(" "),
                    _c("p", [
                      _c("ol", [
                        _c("li", [
                          _vm._v(
                            "Berkembangnya potensi mahasiswa dan dihasilkannya lulusan yang memiliki\n                                        kompetensi dan keunggulan bidang teknologi informasi, berjiwa wirausaha dan\n                                        berakhlak qurani."
                          )
                        ]),
                        _vm._v(" "),
                        _c("li", [
                          _vm._v(
                            "Menghasilkan penelitian yang mendukung pengembangan teknologi informasi dan\n                                        meningkatkan kualitas pembelajaran."
                          )
                        ]),
                        _vm._v(" "),
                        _c("li", [
                          _vm._v(
                            "Terwujudnya pengabdian masyarakat berbasis karya penelitian yang bermanfaat\n                                        bagi masyarakat."
                          )
                        ])
                      ])
                    ]),
                    _vm._v(" "),
                    _c(
                      "a",
                      {
                        attrs: {
                          href: "https://stmikelrahma.ac.id/",
                          target: "_blank"
                        }
                      },
                      [_vm._v("Selengkapnya >>")]
                    )
                  ])
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "modal-footer text-right" }, [
                  _c(
                    "button",
                    {
                      staticClass: "btn btn-danger text-white",
                      attrs: { "data-bs-dismiss": "modal" }
                    },
                    [_c("span", { staticClass: "fa " }), _vm._v(" Tutup")]
                  )
                ])
              ])
            ])
          ]
        )
      ]
    )
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "div",
      {
        staticClass: "modal fade",
        attrs: { id: "ModalTentangLpm", tabindex: "-1", role: "dialog" }
      },
      [
        _c(
          "div",
          {
            staticClass: "modal-dialog text-dark",
            attrs: { role: "document" }
          },
          [
            _c("div", { staticClass: "modal-content" }, [
              _c("div", { staticClass: "modal-header" }, [
                _c("div", { staticClass: "logo-login text-center" }, [
                  _c("em", { staticClass: "glyphicon glyphicon-bookmark" }),
                  _vm._v(" "),
                  _c("h4", { staticClass: "modal-title" }, [
                    _vm._v("Tentang LPM")
                  ])
                ]),
                _vm._v(" "),
                _c("button", {
                  staticClass: "btn-close",
                  attrs: {
                    type: "button",
                    "data-bs-dismiss": "modal",
                    "aria-label": "Close"
                  }
                })
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "modal-body" }, [
                _c("div", { staticClass: "row" }, [
                  _c("div", { staticClass: "col-md-12" }, [
                    _c("h3", [
                      _vm._v("Lembaga Penjaminan Mutu (LPM) - STMIK EL RAHMA")
                    ]),
                    _vm._v(" "),
                    _c("p", [
                      _vm._v(
                        "Lembaga Penjaminan Mutu (LPM) bertugas untuk menyiapkan, merencanakan, merancang,\n                                menetapkan, melaksanakan, mengendalikan, mengevaluasi dan mengembangkan SPMI STMIK\n                                El Rahma."
                      )
                    ]),
                    _vm._v(" "),
                    _c("p", [
                      _vm._v(
                        "Tugas pokok dan fungsi dari Lembaga Penjaminan Mutu (LPM) STMIK El Rahma sebagai\n                                berikut :\n                                "
                      ),
                      _c("ol", [
                        _c("li", [
                          _vm._v(
                            "Merencanakan, melaksanakan, dan mengembangkan SPMI."
                          )
                        ]),
                        _vm._v(" "),
                        _c("li", [
                          _vm._v("Menyusun perangkat pelaksanaan SPMI.")
                        ]),
                        _vm._v(" "),
                        _c("li", [
                          _vm._v("Memonitor dan mengevaluasi pelaksanaan SPMI.")
                        ]),
                        _vm._v(" "),
                        _c("li", [
                          _vm._v(
                            "Melaksanakan dan mengembangkan audit internal."
                          )
                        ]),
                        _vm._v(" "),
                        _c("li", [
                          _vm._v(
                            "Melaporkan pelaksanaan SPMI kepada pimpinan PT."
                          )
                        ]),
                        _vm._v(" "),
                        _c("li", [
                          _vm._v("Menyiapkan SDM penjaminan mutu (auditor).")
                        ])
                      ])
                    ]),
                    _vm._v(" "),
                    _c("p", [
                      _vm._v(
                        "Selain itu LPM juga melaksanakan fungsi pelayanan sebagai berikut :\n                                "
                      ),
                      _c("ol", [
                        _c("li", [
                          _vm._v(
                            "Konsultasi, pendampingan, dan kerja sama di bidang penjaminan mutu."
                          )
                        ]),
                        _vm._v(" "),
                        _c("li", [
                          _vm._v(
                            "Pengembangan sistem informasi penjaminan mutu."
                          )
                        ])
                      ])
                    ])
                  ])
                ])
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "modal-footer text-right" }, [
                _c(
                  "button",
                  {
                    staticClass: "btn btn-danger text-white",
                    attrs: { "data-bs-dismiss": "modal" }
                  },
                  [
                    _c("span", { staticClass: "glyphicon glyphicon-remove" }),
                    _vm._v(" Tutup")
                  ]
                )
              ])
            ])
          ]
        )
      ]
    )
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "div",
      {
        staticClass: "modal fade",
        attrs: { id: "ModalKontak", tabindex: "-1", role: "dialog" }
      },
      [
        _c(
          "div",
          {
            staticClass: "modal-dialog text-dark",
            attrs: { role: "document" }
          },
          [
            _c("div", { staticClass: "modal-content" }, [
              _c("div", { staticClass: "modal-header" }, [
                _c("div", { staticClass: "logo-login text-center" }, [
                  _c("em", { staticClass: "glyphicon glyphicon-user" }),
                  _vm._v(" "),
                  _c("h4", { staticClass: "modal-title" }, [_vm._v("Kontak")])
                ]),
                _vm._v(" "),
                _c("button", {
                  staticClass: "btn-close",
                  attrs: {
                    type: "button",
                    "data-bs-dismiss": "modal",
                    "aria-label": "Close"
                  }
                })
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "modal-body" }, [
                _c("div", { staticClass: "row" }, [
                  _c("div", { staticClass: "col-md-12" }, [
                    _c("span", {
                      staticClass: "glyphicon glyphicon-map-marker"
                    }),
                    _vm._v(
                      " Alamat : Jl. Sisingamangaraja Jl. Karangkajen No.76, Brontokusuman, \n                            Kec. Merganngsan, Kota Yogyakarta, Daerah istimewa Yogyakarta 55791"
                    ),
                    _c("br"),
                    _vm._v(" "),
                    _c("span", {
                      staticClass: "glyphicon glyphicon-phone-alt"
                    }),
                    _vm._v(" Telp. : (0274) 377982"),
                    _c("br"),
                    _vm._v(" "),
                    _c("span", { staticClass: "glyphicon glyphicon-envelope" }),
                    _vm._v(" Email : "),
                    _c("a", { attrs: { href: "", target: "_blank" } }, [
                      _vm._v("pmb@stmikelrahma.ac.id")
                    ])
                  ])
                ])
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "modal-footer text-right" }, [
                _c(
                  "button",
                  {
                    staticClass: "btn btn-danger text-white",
                    attrs: { "data-bs-dismiss": "modal" }
                  },
                  [
                    _c("span", { staticClass: "glyphicon glyphicon-remove" }),
                    _vm._v(" Tutup")
                  ]
                )
              ])
            ])
          ]
        )
      ]
    )
  }
]
render._withStripped = true



/***/ })

}]);