# Start
- php artisan serve
- npm run watch
