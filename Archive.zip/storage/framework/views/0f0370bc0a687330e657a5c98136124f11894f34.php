<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <title>SIJAMU | Sistem Informasi Penjaminan Mutu</title>
</head>

<body>
    <div id="app">
        <template-component></template-component>
    </div>

    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>

</html><?php /**PATH /Users/alvin/Documents/belajar/ami_ami/resources/views/template.blade.php ENDPATH**/ ?>